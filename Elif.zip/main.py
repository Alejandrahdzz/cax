variable=10

if variable==10:
    print("el numero es 10 y la primera condicion se cumple ")


elif variable==20:
     print ("el numero es 20 y el primer elif se cumple ")



elif variable==30:
     print("el numero es 30 y el segundo elif se cumple ")



else:
   print("el numero es 10 y no se cumple la primera concicion ")