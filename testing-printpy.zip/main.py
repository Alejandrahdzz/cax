print("hola mundo")
print("hi my name's alejandra hernandez i'm in 9th D, my favorite food's chocolate, and this is one of my favorite subjects")