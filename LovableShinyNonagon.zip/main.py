import datetime 

dia= datetime.date.today()

w=dia.weekday()+1

if(w==0):
  print('feliz domingo')

elif(w==2):
  print('wuhh es martes')

elif (w==1):
  print('es lunes ')

elif (w==3):
  print('ya es mircoles')

elif (w==4):
  print('ahh es jueves ')

elif (w==5):
  print('eaaa es viernes ')

elif (w==6):
  print('wow sabado')
   


