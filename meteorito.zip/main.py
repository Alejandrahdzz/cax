while True:
  velocity=int(input("la velocidad del metiorito es km/s:" ))

  if velocity>=25:
    print("nos vamos a morir")

  elif(velocity>=20):
    print("estoy a nada de morir")

  elif(velocity>=10):
    print("mira una estrella fugaz")

  else:
   
    print("jajajaja")